import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Home, 
  PieChart, 
  Utensils, 
  Settings as SettingsIcon, 
  Plus, 
  Camera, 
  Mic, 
  MapPin, 
  ChevronRight,
  TrendingDown,
  TrendingUp,
  Award,
  Zap,
  Activity,
  User
} from 'lucide-react';
import { LocationZone, HealthScore, FoodLog, Biometrics, Nudge } from './types';
import { LOCATION_DESCRIPTIONS, MOCK_NUDGES } from './constants';

type Screen = 'dashboard' | 'logging' | 'analytics' | 'settings' | 'onboarding';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('onboarding');
  const [loading, setLoading] = useState(false);
  const [location, setLocation] = useState<LocationZone>('home');
  const [healthScore, setHealthScore] = useState<HealthScore>({
    total: 78,
    breakdown: {
      macros: 85,
      micros: 70,
      timing: 90,
      consistency: 65,
      recovery: 80
    },
    explanation: "Your score is strong! Improving sleep would help recovery metrics."
  });

  const [biometrics, setBiometrics] = useState<Biometrics>({
    steps: 8420,
    caloriesBurned: 450,
    sleepHours: 5.5,
    weightTrend: [75, 74.8, 74.5, 74.6, 74.2, 74.0, 73.8]
  });

  const [logs, setLogs] = useState<FoodLog[]>([]);

  // Simulate context changes
  useEffect(() => {
    const timer = setTimeout(() => {
      // Simulate moving to a fast food area after a delay
      setLocation('fast_food');
    }, 5000);
    return () => clearTimeout(timer);
  }, []);

  // Track patterns
  const [patterns, setPatterns] = useState<string[]>([
    "Late-night snacking detected 3x this week",
    "Weekend consistency dropped by 15%",
    "Post-workout protein alignment improved"
  ]);

  return (
    <div className="bg-slate-100 min-h-screen">
      <div className="mobile-container overflow-hidden">
        <AnimatePresence mode="wait">
          {currentScreen === 'onboarding' && (
            <OnboardingScreen onComplete={() => setCurrentScreen('dashboard')} />
          )}
          {currentScreen === 'dashboard' && (
            <DashboardScreen 
              location={location} 
              healthScore={healthScore} 
              biometrics={biometrics}
              patterns={patterns}
              onLogClick={() => setCurrentScreen('logging')}
            />
          )}
          {currentScreen === 'logging' && (
            <LoggingScreen 
              onBack={() => setCurrentScreen('dashboard')}
              onLogAdded={(log) => {
                setLogs([log, ...logs]);
                setCurrentScreen('dashboard');
              }}
            />
          )}
          {currentScreen === 'analytics' && (
            <AnalyticsScreen biometrics={biometrics} logs={logs} />
          )}
          {currentScreen === 'settings' && (
            <SettingsScreen />
          )}
        </AnimatePresence>

        {currentScreen !== 'onboarding' && (
          <nav className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-white border-t border-gray-100 flex items-center justify-around h-20 px-8 z-50">
            <NavItem icon={<Home size={22} />} label="Overview" active={currentScreen === 'dashboard'} onClick={() => setCurrentScreen('dashboard')} />
            <NavItem icon={<PieChart size={22} />} label="Analytics" active={currentScreen === 'analytics'} onClick={() => setCurrentScreen('analytics')} />
            
            <button 
              onClick={() => setCurrentScreen('logging')}
              className="w-14 h-14 bg-primary-500 rounded-full -mt-10 shadow-lg border-4 border-white flex items-center justify-center text-white text-2xl active:scale-90 transition-transform"
            >
              <Plus size={24} />
            </button>

            <NavItem icon={<MapPin size={22} />} label="Plan" active={false} onClick={() => {}} />
            <NavItem icon={<SettingsIcon size={22} />} label="Profile" active={currentScreen === 'settings'} onClick={() => setCurrentScreen('settings')} />
          </nav>
        )}
      </div>
    </div>
  );
}

function NavItem({ icon, label, active, onClick }: { icon: React.ReactNode, label: string, active: boolean, onClick: () => void }) {
  return (
    <button onClick={onClick} className={`nav-item ${active ? 'active' : ''}`}>
      {icon}
      <span className="text-[10px] mt-1 font-medium">{label}</span>
    </button>
  );
}

function OnboardingScreen({ onComplete }: { onComplete: () => void }) {
  const [step, setStep] = useState(0);
  const steps = [
    { title: "Welcome to NourishIQ", subtitle: "Effortless Health, Intelligently Yours.", image: "https://images.unsplash.com/photo-1490645935967-10de6ba17061?auto=format&fit=crop&q=80&w=600" },
    { title: "Context Aware", subtitle: "We use location and time to guide your choices without tracking every bite.", image: "https://images.unsplash.com/photo-1543332164-6e82f355bab1?auto=format&fit=crop&q=80&w=600" },
    { title: "Nudge Technology", subtitle: "Actionable insights based on your biometrics and patterns.", image: "https://images.unsplash.com/photo-1476480862126-209bfaa8edc8?auto=format&fit=crop&q=80&w=600" }
  ];

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="flex-1 flex flex-col p-8 bg-white h-full"
    >
      <div className="flex-1 flex flex-col items-center justify-center text-center">
        <motion.img 
          key={step}
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          src={steps[step].image} 
          className="w-64 h-64 object-cover rounded-3xl mb-8 shadow-xl"
        />
        <h1 className="text-3xl font-bold mb-4">{steps[step].title}</h1>
        <p className="text-slate-500 mb-12">{steps[step].subtitle}</p>
      </div>
      
      <div className="flex justify-between items-center mb-8">
        <div className="flex gap-2">
          {steps.map((_, i) => (
            <div key={i} className={`h-1.5 rounded-full transition-all duration-300 ${i === step ? 'w-8 bg-primary-500' : 'w-2 bg-slate-200'}`} />
          ))}
        </div>
        <button 
          onClick={() => step < steps.length - 1 ? setStep(step + 1) : onComplete()}
          className="bg-primary-500 text-white px-8 py-3 rounded-2xl font-semibold shadow-lg shadow-primary-500/20 active:scale-95 transition-transform"
        >
          {step === steps.length - 1 ? 'Start Now' : 'Continue'}
        </button>
      </div>
    </motion.div>
  );
}

function DashboardScreen({ location, healthScore, biometrics, patterns, onLogClick }: { 
  location: LocationZone, 
  healthScore: HealthScore, 
  biometrics: Biometrics,
  patterns: string[],
  onLogClick: () => void 
}) {
  return (
    <motion.div 
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="flex-1 flex flex-col p-6 pb-24 space-y-6 overflow-y-auto"
    >
      <header className="flex justify-between items-center px-6 py-6 bg-white border-b border-gray-100">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-primary-500 rounded-xl flex items-center justify-center">
            <div className="w-5 h-5 bg-white rounded-full opacity-90"></div>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-dark-950">
            Nourish<span className="text-primary-500">IQ</span>
          </h1>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex flex-col items-end hidden sm:flex">
            <span className="text-[10px] font-bold uppercase tracking-widest text-gray-400">System Status</span>
            <span className="text-xs font-medium text-green-600">AI Active</span>
          </div>
          <div className="w-10 h-10 rounded-full bg-slate-100 border-2 border-white shadow-sm flex items-center justify-center">
             <User size={20} className="text-slate-400" />
          </div>
        </div>
      </header>

      {/* Health Score Card */}
      <div className="bg-white rounded-[32px] p-8 shadow-sm border border-gray-100 flex flex-col items-center justify-center text-center relative overflow-hidden">
        <div className="absolute top-0 right-0 p-4">
          <span className="badge-green">+4 pts</span>
        </div>
        <span className="text-xs font-bold uppercase tracking-widest text-gray-400 mb-6">Daily Health Score</span>
        
        <div className="relative w-40 h-40 flex items-center justify-center">
          <svg className="w-full h-full transform -rotate-90">
            <circle cx="80" cy="80" r="72" stroke="#F1F5F9" strokeWidth="10" fill="transparent" />
            <circle 
              cx="80" cy="80" r="72" 
              stroke="#2D6A4F" strokeWidth="10" 
              strokeDasharray={452} 
              strokeDashoffset={452 - (452 * healthScore.total) / 100} 
              strokeLinecap="round" 
              fill="transparent" 
              className="transition-all duration-1000 ease-out"
            />
          </svg>
          <div className="absolute flex flex-col items-center">
            <span className="text-5xl font-black text-dark-950">{healthScore.total}</span>
            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Optimal</span>
          </div>
        </div>

        <p className="mt-8 text-sm text-gray-500 leading-relaxed px-4">
          {healthScore.explanation}
        </p>

        <div className="flex justify-between w-full mt-8 pt-6 border-t border-gray-50">
           {Object.entries(healthScore.breakdown).map(([key, val]) => (
             <div key={key} className="flex flex-col items-center">
               <span className="text-[9px] text-gray-400 font-bold uppercase tracking-tighter">{key}</span>
               <span className="text-xs font-black text-primary-500">{val}%</span>
             </div>
           ))}
        </div>
      </div>

      {/* Contextual Nudge */}
      {location === 'fast_food' && (
        <motion.div 
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="bg-gradient-to-br from-primary-500 to-primary-600 rounded-[32px] p-8 text-white relative overflow-hidden shadow-lg shadow-primary-500/10"
        >
          <div className="relative z-10">
             <div className="flex items-center gap-2 mb-3">
                <span className="bg-white/20 px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-tighter flex items-center gap-1">
                   <MapPin size={10} /> Fast Food Area
                </span>
             </div>
             <h4 className="text-2xl font-bold mb-2">Healthy Swap</h4>
             <p className="text-white/80 text-sm leading-relaxed mb-6">{MOCK_NUDGES[0].message}</p>
             <div className="flex gap-3">
               <button className="bg-white text-primary-500 px-6 py-2 rounded-full text-xs font-bold shadow-lg">
                 {MOCK_NUDGES[0].actionLabel}
               </button>
               <button className="bg-white/10 border border-white/20 px-6 py-2 rounded-full text-xs font-bold">
                 Dismiss
               </button>
             </div>
          </div>
          <div className="absolute -right-10 -bottom-10 w-40 h-40 bg-white/10 rounded-full blur-3xl"></div>
        </motion.div>
      )}

      {biometrics.sleepHours < 6 && (
        <motion.div 
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="bg-dark-800 rounded-[32px] p-8 text-white relative overflow-hidden"
        >
          <div className="flex items-center gap-2 mb-4">
             <span className="bg-amber-500/20 text-amber-500 px-3 py-1 rounded-full text-[10px] font-bold uppercase">Recovery Active</span>
          </div>
          <h4 className="text-2xl font-bold mb-2">Recovery Mode</h4>
          <p className="text-white/60 text-sm leading-relaxed mb-6">{MOCK_NUDGES[1].message}</p>
          <button className="text-white text-sm font-bold flex items-center gap-1">
             Learn strategy <ChevronRight size={14} />
          </button>
        </motion.div>
      )}

      {/* Biometrics Summary */}
      <div className="grid grid-cols-2 gap-4">
        <StatCard 
          icon={<TrendingUp className="text-orange-500" size={20} />}
          label="Steps"
          value={biometrics.steps.toLocaleString()}
          unit="steps"
          color="bg-orange-50"
        />
        <StatCard 
          icon={<Award className="text-purple-500" size={20} />}
          label="Calories"
          value={biometrics.caloriesBurned}
          unit="burned"
          color="bg-purple-50"
        />
      </div>

      {/* Insights Section */}
      <div className="space-y-4">
        <h4 className="font-bold px-2 text-dark-950 flex items-center justify-between">
          <span className="uppercase text-xs tracking-widest text-gray-400">Behavioral Insights</span>
          <span className="text-[10px] font-medium text-gray-400">Last 7 Days</span>
        </h4>
        {patterns.map((p, i) => (
          <div key={i} className="flex items-start gap-4 p-2">
             <div className={`w-1.5 h-12 rounded-full ${i === 0 ? 'bg-amber-400' : 'bg-primary-500'}`}></div>
             <div>
               <p className="text-sm font-bold text-dark-950">{p}</p>
               <p className="text-[11px] text-gray-400 italic mt-1 font-serif">"Context AI suggests hydration focus today."</p>
             </div>
          </div>
        ))}
      </div>

      {/* Streak Section */}
      <div className="glass-card">
        <div className="flex justify-between items-center mb-4">
          <h4 className="font-bold">Growth Heatmap</h4>
          <span className="text-xs text-slate-400">Past 30 days</span>
        </div>
        <div className="grid grid-cols-10 gap-1">
          {Array.from({ length: 30 }).map((_, i) => (
            <div 
              key={i} 
              className={`aspect-square rounded-[4px] ${
                i % 4 === 0 ? 'bg-primary-500' : 
                i % 7 === 0 ? 'bg-primary-200' :
                i % 3 === 0 ? 'bg-primary-400' : 'bg-slate-100'
              }`} 
            />
          ))}
        </div>
      </div>
    </motion.div>
  );
}

function StatCard({ icon, label, value, unit, color }: { icon: React.ReactNode, label: string, value: string | number, unit: string, color: string }) {
  return (
    <div className={`p-4 rounded-3xl ${color} flex flex-col gap-2`}>
      <div className="bg-white w-8 h-8 rounded-xl flex items-center justify-center shadow-sm">
        {icon}
      </div>
      <div>
        <p className="text-slate-500 text-xs font-medium uppercase tracking-wider">{label}</p>
        <p className="text-xl font-bold">{value} <span className="text-[10px] text-slate-400 font-normal uppercase">{unit}</span></p>
      </div>
    </div>
  );
}

function LoggingScreen({ onBack, onLogAdded }: { onBack: () => void, onLogAdded: (log: FoodLog) => void }) {
  const [input, setInput] = useState('');
  const [method, setMethod] = useState<'camera' | 'voice' | 'manual'>('manual');
  const [analyzing, setAnalyzing] = useState(false);

  const handleLog = async () => {
    if (!input.trim() && method === 'manual') return;
    setAnalyzing(true);
    
    setTimeout(() => {
      onLogAdded({
        id: Math.random().toString(),
        food: input || "Vision capture: Greek Salad",
        calories: 320,
        protein: 24,
        carbs: 12,
        fat: 18,
        timestamp: new Date().toISOString(),
        method: method,
        healthScore: 9
      });
      setAnalyzing(false);
    }, 2000);
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 100 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 100 }}
      className="flex-1 flex flex-col bg-surface-50 h-full p-6 pt-12"
    >
      <header className="flex justify-between items-center mb-10 px-2">
        <h2 className="text-3xl font-black text-dark-950">Quick Log</h2>
        <button onClick={onBack} className="text-gray-400 font-bold text-sm uppercase tracking-wider">Cancel</button>
      </header>

      <div className="flex-1 flex flex-col space-y-8">
        <div className="bg-[#F2F7F5] rounded-[32px] p-8 border-2 border-dashed border-primary-500/20 flex flex-col items-center">
          <p className="text-[10px] font-bold text-primary-500 uppercase tracking-widest mb-8 italic">Log in &lt; 3 seconds</p>
          <div className="flex gap-6">
            <LogTab icon={<Camera size={28} />} active={method === 'camera'} onClick={() => setMethod('camera')} label="Vision" />
            <LogTab icon={<Mic size={28} />} active={method === 'voice'} onClick={() => setMethod('voice')} label="Voice" />
            <LogTab icon={<Plus size={28} />} active={method === 'manual'} onClick={() => setMethod('manual')} label="Quick" />
          </div>
        </div>

        {method === 'manual' ? (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
            <label className="text-gray-400 text-xs font-bold uppercase tracking-widest ml-2">What did you eat?</label>
            <textarea 
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="e.g., Avocado toast with 2 poached eggs..."
              className="w-full h-40 bg-white rounded-[24px] p-8 border border-gray-100 shadow-sm focus:ring-4 focus:ring-primary-500/5 transition-all outline-none resize-none font-medium leading-relaxed"
            />
          </motion.div>
        ) : (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex-1 flex flex-col items-center justify-center p-8 bg-white rounded-[32px] border border-gray-100 shadow-sm">
             <div className="w-24 h-24 bg-primary-50 text-primary-500 rounded-full flex items-center justify-center animate-pulse mb-6 border-4 border-white shadow-xl">
                {method === 'camera' ? <Camera size={32} /> : <Mic size={32} />}
             </div>
             <p className="font-black text-xl text-dark-950">Ready to capture</p>
             <p className="text-gray-400 text-sm text-center px-4 mt-2">
                NourishIQ AI identifies nutrients instantly using on-device vision.
             </p>
          </motion.div>
        )}
      </div>

      <button 
        onClick={handleLog}
        disabled={analyzing}
        className="w-full bg-primary-500 text-white py-6 rounded-full font-black text-lg shadow-2xl shadow-primary-500/30 active:scale-95 transition-all mt-6 flex items-center justify-center gap-3"
      >
        {analyzing ? (
          <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 1 }}><Zap size={24} /></motion.div>
        ) : 'Analyze & Sync'}
      </button>
    </motion.div>
  );
}

function LogTab({ icon, active, onClick, label }: { icon: React.ReactNode, active: boolean, onClick: () => void, label: string }) {
  return (
    <div className="flex flex-col items-center">
      <button 
        onClick={onClick}
        className={`w-16 h-16 rounded-2xl shadow-sm flex items-center justify-center transition-all border ${active ? 'bg-primary-500 text-white border-primary-500 scale-110 z-10' : 'bg-white text-gray-400 border-gray-100 hover:border-primary-100'}`}
      >
        {icon}
      </button>
      <span className="text-[10px] font-bold uppercase text-gray-400 mt-3 tracking-widest">{label}</span>
    </div>
  );
}

function AnalyticsScreen({ biometrics, logs }: { biometrics: Biometrics, logs: FoodLog[] }) {
  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      className="flex-1 flex flex-col p-6 pb-24 space-y-6 overflow-y-auto"
    >
      <h2 className="text-2xl font-bold">Health Analytics</h2>
      
      <div className="glass-card">
         <h3 className="font-bold mb-4">Weight Trend</h3>
         <div className="flex items-end justify-between h-32 gap-1 px-2">
            {biometrics.weightTrend.map((v, i) => (
              <div key={i} className="flex-1 flex flex-col items-center gap-2">
                 <div 
                  className="w-full bg-primary-500/60 rounded-t-lg transition-all hover:bg-primary-500" 
                  style={{ height: `${(v / 80) * 100}%` }}
                 />
                 <span className="text-[8px] text-slate-400">{v}kg</span>
              </div>
            ))}
         </div>
      </div>

      <div className="glass-card">
         <h3 className="font-bold mb-2">Meal Timing Patterns</h3>
         <p className="text-slate-500 text-sm mb-4">Detected: consistent midday fueling, but early morning gap.</p>
         <div className="relative h-4 w-full bg-slate-100 rounded-full overflow-hidden flex">
            <div className="h-full bg-primary-200 w-1/4" />
            <div className="h-full bg-primary-500 w-1/2" />
            <div className="h-full bg-amber-400 w-1/4" />
         </div>
         <div className="flex justify-between mt-2 text-[10px] font-medium text-slate-400">
            <span>6 AM</span>
            <span>12 PM</span>
            <span>6 PM</span>
            <span>12 AM</span>
         </div>
      </div>

      <div>
        <h3 className="font-bold mb-4">Recent Insights</h3>
        <div className="space-y-3">
          {logs.map((log) => (
            <div key={log.id} className="p-4 bg-white rounded-2xl border border-slate-100 flex justify-between items-center">
              <div>
                <p className="font-semibold text-slate-800">{log.food}</p>
                <div className="flex gap-2 text-[10px] text-slate-400 mt-1 uppercase font-bold tracking-tighter">
                   <span>{log.calories} kcal</span>
                   <span>P: {log.protein}g</span>
                   <span>C: {log.carbs}g</span>
                </div>
              </div>
              <div className="bg-primary-50 text-primary-600 px-3 py-1 rounded-full text-xs font-bold">
                 +{log.healthScore}
              </div>
            </div>
          ))}
          {logs.length === 0 && (
            <p className="text-slate-400 text-sm text-center py-8">No logs yet today.</p>
          )}
        </div>
      </div>
    </motion.div>
  );
}

function SettingsScreen() {
  return (
    <motion.div 
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 20 }}
      className="flex-1 flex flex-col p-6 pb-24 space-y-6 overflow-y-auto"
    >
      <h2 className="text-2xl font-bold">Settings</h2>
      
      <div className="space-y-4">
        <section>
          <h3 className="text-slate-400 text-xs font-bold uppercase tracking-widest mb-3 ml-2">Profile</h3>
          <div className="glass-card divide-y divide-slate-100 p-0">
             <SettingsItem icon={<User size={18} />} label="Personal Information" />
             <SettingsItem icon={<TrendingUp size={18} />} label="Health Goals" />
             <SettingsItem icon={<Activity size={18} />} label="Biometrics Sync (Connected)" />
          </div>
        </section>

        <section>
          <h3 className="text-slate-400 text-xs font-bold uppercase tracking-widest mb-3 ml-2">Privacy & IQ</h3>
          <div className="glass-card divide-y divide-slate-100 p-0">
             <SettingsItem icon={<MapPin size={18} />} label="Location Awareness" toggle active />
             <SettingsItem icon={<Zap size={18} />} label="Predictive Nudges" toggle active />
             <SettingsItem icon={<SettingsIcon size={18} />} label="Privacy Mode (On-device)" toggle active={false} />
          </div>
        </section>
      </div>
    </motion.div>
  );
}

function SettingsItem({ icon, label, toggle, active }: { icon: React.ReactNode, label: string, toggle?: boolean, active?: boolean }) {
  return (
    <div className="flex justify-between items-center p-4">
      <div className="flex items-center gap-3">
        <div className="text-slate-400">{icon}</div>
        <span className="font-medium text-slate-700">{label}</span>
      </div>
      {toggle ? (
        <div className={`w-10 h-5 rounded-full transition-colors relative ${active ? 'bg-primary-500' : 'bg-slate-200'}`}>
           <div className={`absolute top-1 w-3 h-3 bg-white rounded-full transition-all ${active ? 'left-6' : 'left-1'}`} />
        </div>
      ) : (
        <ChevronRight size={16} className="text-slate-300" />
      )}
    </div>
  );
}
