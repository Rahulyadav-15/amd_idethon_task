import { LocationZone } from './types';

export const LOCATION_DESCRIPTIONS: Record<LocationZone, string> = {
  home: "At Home - Time to cook something fresh?",
  work: "At Work - Staying productive and hydrated.",
  fast_food: "Near Fast Food - Need a healthy swap?",
  grocery: "At Grocery - Smart shopping list ready.",
  gym: "At the Gym - Post-workout protein incoming?",
  unknown: "On the move."
};

export const MOCK_NUDGES = [
  {
    id: '1',
    type: 'ambient',
    title: 'Healthy Swap detected',
    message: "You're at McDonald's → Grilled Chicken Wrap saves 320 kcal vs Big Mac.",
    reason: "Location detection: fast_food zone",
    actionLabel: "View Swaps"
  },
  {
    id: '2',
    type: 'recovery',
    title: 'Recovery Mode',
    message: "Sleep was < 6hrs today. Focus on high-protein, low-sugar meals to manage cortisol.",
    reason: "Biometric signal: Low sleep duration",
    actionLabel: "Recovery Meals"
  }
];
