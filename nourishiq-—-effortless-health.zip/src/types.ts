export interface HealthScore {
  total: number;
  breakdown: {
    macros: number;
    micros: number;
    timing: number;
    consistency: number;
    recovery: number;
  };
  explanation: string;
}

export interface FoodLog {
  id: string;
  food: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  timestamp: string;
  method: 'camera' | 'voice' | 'manual' | 'grocery';
  healthScore: number;
}

export interface Biometrics {
  steps: number;
  caloriesBurned: number;
  sleepHours: number;
  weightTrend: number[];
}

export interface Nudge {
  id: string;
  type: 'ambient' | 'recovery' | 'streak';
  title: string;
  message: string;
  reason: string;
  actionLabel: string;
}

export type LocationZone = 'home' | 'work' | 'fast_food' | 'grocery' | 'gym' | 'unknown';
