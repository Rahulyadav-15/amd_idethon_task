import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Simple in-memory "database" for the prototype
  const healthData = {
    logs: [],
    biometrics: {
      steps: 8420,
      caloriesBurned: 450,
      sleepHours: 5.5,
    },
    location: "home", // simulated location: home, workplace, fast_food, grocery
  };

  // API Routes
  app.get("/api/health-data", (req, res) => {
    res.json(healthData);
  });

  app.post("/api/food-log", async (req, res) => {
    const { food, method } = req.body;
    
    // Simulate AI Vision/NLP processing with Gemini
    const apiKey = process.env.GEMINI_API_KEY;
    let aiInsight = "Analyzing food...";
    
    if (apiKey) {
      try {
        const genAI = new GoogleGenAI(apiKey);
        const model = genAI.getGenerativeModel({ model: "gemini-2.0-flash" });
        const prompt = `Analyze this food: "${food}". Provide nutritional info (cal, protein, carbs, fats) and a "Health Impact Score" (1-10). Return as JSON.`;
        const result = await model.generateContent(prompt);
        aiInsight = result.response.text();
      } catch (e) {
        console.error("Gemini API Error:", e);
      }
    }

    const newLog = {
      id: Date.now().toString(),
      food,
      method,
      timestamp: new Date().toISOString(),
      insight: aiInsight,
    };
    
    healthData.logs.push(newLog);
    res.json(newLog);
  });

  app.post("/api/simulate-location", (req, res) => {
    healthData.location = req.body.location;
    res.json({ status: "success", location: healthData.location });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
